import React, { useState, useRef, useCallback } from 'react';
import svgPaths from "../imports/svg-6q0evb2n6r";

interface ActivityWheelProps {
  onSelectionChange?: (selection: 'oui-plus' | 'oui-moins' | 'non' | null) => void;
}

export function ActivityWheel({ onSelectionChange }: ActivityWheelProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selection, setSelection] = useState<'oui-plus' | 'oui-moins' | 'non' | null>(null);
  const [selectorPosition, setSelectorPosition] = useState({ x: 50, y: 50 }); // Center position as percentage
  const wheelRef = useRef<HTMLDivElement>(null);
  const selectorRef = useRef<HTMLDivElement>(null);

  const getSelectionFromAngle = (angle: number): 'oui-plus' | 'oui-moins' | 'non' => {
    // Normalize angle to 0-360 degrees
    let normalizedAngle = ((angle * 180 / Math.PI) + 360) % 360;
    
    // Define sectors: 
    // Top-left (oui-plus): 150-270 degrees
    // Top-right (oui-moins): 270-30 degrees (crosses 0)
    // Bottom (non): 30-150 degrees
    
    if (normalizedAngle >= 30 && normalizedAngle <= 150) {
      return 'non';
    } else if (normalizedAngle >= 150 && normalizedAngle <= 270) {
      return 'oui-plus';
    } else {
      return 'oui-moins';
    }
  };

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    e.preventDefault();
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging || !wheelRef.current) return;

    const rect = wheelRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    // Calculate position relative to wheel center
    const deltaX = e.clientX - centerX;
    const deltaY = e.clientY - centerY;
    
    // Convert to percentage within wheel bounds
    const wheelRadius = rect.width / 2 * 0.8; // 80% of wheel radius to keep selector inside
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    
    if (distance <= wheelRadius) {
      const newX = ((deltaX / rect.width) * 100) + 50;
      const newY = ((deltaY / rect.height) * 100) + 50;
      setSelectorPosition({ x: newX, y: newY });
      
      // Calculate angle for sector detection
      const angle = Math.atan2(-deltaY, deltaX); // Negative deltaY because screen coordinates are flipped
      const newSelection = getSelectionFromAngle(angle);
      
      if (newSelection !== selection) {
        setSelection(newSelection);
        onSelectionChange?.(newSelection);
      }
    }
  }, [isDragging, selection, onSelectionChange]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  React.useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Roue">
      <div 
        ref={wheelRef}
        className="[grid-area:1_/_1] ml-0 mt-0 relative size-[340px] cursor-pointer select-none" 
        data-name="Vector"
      >
        <div className="absolute inset-[-0.441%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 344 344">
            <g id="Vector">
              <path d={svgPaths.p28366a80} fill="var(--fill-0, white)" />
              <path d={svgPaths.p27b94700} fill="var(--fill-0, white)" />
              <path d={svgPaths.p1a844a00} stroke="var(--stroke-0, #DADADA)" strokeWidth="3" />
              
              {/* Visual feedback for selection */}
              {selection === 'oui-plus' && (
                <path 
                  d="M172 2C78.1116 2 2 78.1116 2 172L172 172L172 2Z" 
                  fill="rgba(14, 122, 254, 0.1)" 
                />
              )}
              {selection === 'oui-moins' && (
                <path 
                  d="M172 2C265.888 2 342 78.1116 342 172L172 172L172 2Z" 
                  fill="rgba(14, 122, 254, 0.1)" 
                />
              )}
              {selection === 'non' && (
                <path 
                  d="M2 172C2 265.888 78.1116 342 172 342C265.888 342 342 265.888 342 172L172 172L2 172Z" 
                  fill="rgba(14, 122, 254, 0.1)" 
                />
              )}
            </g>
          </svg>
        </div>
      </div>
      
      {/* Labels - positioned according to the three sections */}
      <div className={`[grid-area:1_/_1] font-['SF_Pro_Display:Semibold',_sans-serif] ml-[87px] mt-[98px] not-italic relative text-[16px] text-center translate-x-[-50%] w-[92px] pointer-events-none transition-colors ${selection === 'oui-plus' ? 'text-[#0e7afe]' : 'text-black'}`}>
        <p className="leading-[normal]">
          Oui,
          <br aria-hidden="true" />
          + de 30 mins
        </p>
      </div>
      
      <div className={`[grid-area:1_/_1] font-['SF_Pro_Display:Semibold',_sans-serif] ml-[253px] mt-[98px] not-italic relative text-[16px] text-center translate-x-[-50%] w-[92px] pointer-events-none transition-colors ${selection === 'oui-moins' ? 'text-[#0e7afe]' : 'text-black'}`}>
        <p className="leading-[normal]">
          Oui,
          <br aria-hidden="true" />
          - de 30 mins
        </p>
      </div>
      
      <div className={`[grid-area:1_/_1] font-['SF_Pro_Display:Semibold',_sans-serif] ml-[170px] mt-[250px] not-italic relative text-[16px] text-center translate-x-[-50%] w-[92px] pointer-events-none transition-colors ${selection === 'non' ? 'text-[#0e7afe]' : 'text-black'}`}>
        <p className="leading-[normal]">Non</p>
      </div>
      
      {/* Draggable Selector */}
      <div 
        ref={selectorRef}
        className="absolute transition-all duration-200 ease-out cursor-grab active:cursor-grabbing"
        style={{
          left: `${selectorPosition.x}%`,
          top: `${selectorPosition.y}%`,
          transform: 'translate(-50%, -50%)',
          width: '43px',
          height: '43px',
          zIndex: 10
        }}
        onMouseDown={handleMouseDown}
      >
        <div className="absolute inset-[-45.12%_-35.81%_-26.51%_-35.81%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 75 75">
            <g filter="url(#filter0_d_2_158)" id="Ellipse 1487">
              <circle 
                cx="37.5" 
                cy="41.5" 
                fill={isDragging ? "rgba(14, 122, 254, 0.9)" : "var(--fill-0, white)"} 
                r="21.5" 
                className="transition-colors duration-200"
              />
              <circle 
                cx="37.5" 
                cy="41.5" 
                r="21" 
                stroke={isDragging ? "#0e7afe" : "var(--stroke-0, #DADADA)"} 
                className="transition-colors duration-200"
              />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="73.8" id="filter0_d_2_158" width="73.8" x="0.6" y="0.6">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                <feOffset dy="-4" />
                <feGaussianBlur stdDeviation="7.7" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0" />
                <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_2_158" />
                <feBlend in="SourceGraphic" in2="effect1_dropShadow_2_158" mode="normal" result="shape" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
    </div>
  );
}